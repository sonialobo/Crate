﻿using Beehive.Test;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace Beehive.Global
{
    internal class Login
    {
        // Initializing the web elements 
        internal Login()
        {
            PageFactory.InitElements(Driver.driver, this);
        }

        // Finding the E-mail Field
        [FindsBy(How = How.Id, Using = "UserName")]
        private IWebElement eMail { get; set; }

        // Finding the Password Field
        [FindsBy(How = How.Id, Using = "Password")]
        private IWebElement passWord { get; set; }

        // Finding the Login Button
        [FindsBy(How = How.XPath, Using = "html/body/div/form/button")]
        private IWebElement loginButton { get; set; }

        internal void LoginSuccessfull()
        {
            // Populating the data from Excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Login");
            // Navigating to Login page using value from Excel
            Driver.driver.Navigate().GoToUrl(ExcelLib.ReadData(2,"url"));
            // Sending the username 
            eMail.SendKeys(ExcelLib.ReadData(2, "Username"));
            // Sending the password
            passWord.SendKeys(ExcelLib.ReadData(2, "Password"));
            // Clicking on the login button
            loginButton.Click();
        }
    }
}