﻿There are mainly four folders in the automation framework. 
1. Config - Contains all the constant values 
2. Gloabl - Driver definition, wait methods, excel, screen shots etc. 
3. Pages - definition of page elements, methods of each page
4. Tests - Only the tests, derived from the base.cs
			base.cs contains the set up and tear down methods. & it reads data from app.config file
