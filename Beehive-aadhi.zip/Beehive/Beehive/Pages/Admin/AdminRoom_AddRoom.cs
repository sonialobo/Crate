﻿using Beehive.Global;
using Beehive.Test;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Threading;

namespace Beehive.Pages.Admin
{
    internal class AdminRoom_AddRoom
    {
        // create for demo
        public AdminRoom_AddRoom()
        {
            PageFactory.InitElements(Driver.driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Admin')]")]
        private IWebElement AdminLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Room Settings')]")]
        private IWebElement RoomSettingLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Add Room')]")]
        private IWebElement AddRoomBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'AssetName')]")]
        private IWebElement RoomNameTB { get; set; }

        [FindsBy(How =How.XPath, Using = "//input[@id='MacAddress']")]
        private IWebElement macAddressTB { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(.,'Add New')]")]
        private IWebElement AddNewBtn { get; set; }

        public void AddRoom_CommonSteps()
        {
            // clicking on the admin link
            AdminLink.Click();
            Base.test.Log(LogStatus.Info, "Clicked on the Admin Link");
            //Clicking on the room settings link
            RoomSettingLink.Click();
            Base.test.Log(LogStatus.Info, "Clicked on the Room Settings Link on the left side of the page");
            // Clicking on the Add Room Button
            
        }

        internal void AddRoom()
        {
            // popluating the data from excel with the sheet name Admin
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Admin");

            AddRoom_CommonSteps();
           
            AddRoomBtn.Click();
            Base.test.Log(LogStatus.Info, "Clicked on Add Room Button");
            
            // sending the room name to the Room Name text box
            RoomNameTB.SendKeys(ExcelLib.ReadData(5, "RoomName"));
            macAddressTB.SendKeys(ExcelLib.ReadData(5,"macAddress"));
            Base.test.Log(LogStatus.Info, "Entered the room name into the text field " + ExcelLib.ReadData(5, "RoomName") + " & MAC Address  " + ExcelLib.ReadData(5,"macAddress"));
            // clicking on the add new button
            AddNewBtn.Click();

            VerifyData(ExcelLib.ReadData(5, "RoomName"));

        }

        internal void VerifyData(string roomNameToVerify)
        {
            Thread.Sleep(500);
            RoomSettingLink.Click();
            int i = 1;
            bool found = false;
            string roomName;
            try
            {
                while (true)
                {
                    roomName = Driver.driver.FindElement(By.XPath(".//*[@id='Room-List']/tr[" + i + "]/td[2]")).Text;
                    if (roomName == roomNameToVerify)// ExcelLib.ReadData(5, "RoomName"))
                    {
                        found = true;
                        Base.test.Log(LogStatus.Pass, "test success and found the room : " + roomName);
                        break;
                    }
                    else
                    {
                        i++;
                        //Console.WriteLine(roomName+ "   "+ ExcelLib.ReadData(5,"Roomname"));
                    }
                }
            }
            catch (Exception exceptionVariable)
            {
                Console.WriteLine(exceptionVariable);
            }
            if (found == false)
                Base.test.Log(LogStatus.Fail, "Room couldnot found");
        }
        internal void AddRoom_InvalidData()
        {
            // a common method for addinf 
            AddRoom_CommonSteps();
            AddRoomBtn.Click();
            Base.test.Log(LogStatus.Info, "Clicked on Add Room Button");
            // popluating the data from excel with the sheet name Admin
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Admin");
            // sending the room name to the Room Name text box
            RoomNameTB.SendKeys(ExcelLib.ReadData(7, "RoomName"));
            macAddressTB.SendKeys(ExcelLib.ReadData(7, "macAddress"));
            Base.test.Log(LogStatus.Info, "Entered the room name into the text field " + ExcelLib.ReadData(7, "RoomName") + "MAC Address " + ExcelLib.ReadData(7, "macAddress"));
            // clicking on the add new button
            String img = SaveScreenShotClass.SaveScreenshot(Driver.driver, "AddRoom_InvalidData");
            Base.test.Log(LogStatus.Info, "Invalid Data Screenshot  " + img);
            AddNewBtn.Click();
            Base.test.Log(LogStatus.Fail, "Could not complete the test without fixing the bug");
        }
        internal void AddRoom_BlankData()
        {
            // logic
            AddRoom_CommonSteps();
            AddRoomBtn.Click();
            Base.test.Log(LogStatus.Info, "Clicked on Add Room Button");
            AddNewBtn.Click();
            Base.test.Log(LogStatus.Fail, "The system should give a warning message");
        }
        internal void AddRoom_DuplicateData()
        {
            //logic
            AddRoom_CommonSteps();
            AddRoomBtn.Click();
            Base.test.Log(LogStatus.Info, "Clicked on Add Room Button");
            AddNewBtn.Click();
            Base.test.Log(LogStatus.Fail, "Couldn't automate without fixing the bug");
        }
        internal void AddRoom_EditData()
        {
            try
            {
                AddRoom_CommonSteps();
                // popluating the data from excel with the sheet name Admin
                ExcelLib.PopulateInCollection(Base.ExcelPath, "Admin");
                // calling a method to find the room to edit
                int a = FindRoomToEdit(ExcelLib.ReadData(10, "RoomName"));
                Console.WriteLine(a);
                // clicking on the edit button
                Driver.driver.FindElement(By.XPath(".//*[@id='Room-List']/tr[" + a + "]/td[3]/a")).Click();
                // clearing the data on 
                Driver.driver.FindElement(By.XPath("//input[@id='RoomName']")).Clear();
                // storing the roomname to be edited in a string
                string editRoomName = ExcelLib.ReadData(14, "RoomName");
                Driver.driver.FindElement(By.XPath("//input[@id='RoomName']")).SendKeys(editRoomName);
                Base.test.Log(LogStatus.Info, "The updated room name is   " + editRoomName);
                // clicking on update button
                Driver.driver.FindElement(By.XPath("//input[@type='submit']")).Click();
                Thread.Sleep(500);
                VerifyData(editRoomName);
            }
            catch (Exception e)
            {
                Base.test.Log(LogStatus.Fail, "Error", e);
            }
        }
        private int FindRoomToEdit(string RoomEdit)
        {
            string roomName;
            int i = 1;
            try
            {
                while (true)
                {
                    roomName = Driver.driver.FindElement(By.XPath(".//*[@id='Room-List']/tr[" + i + "]/td[2]")).Text;
                    if (roomName == RoomEdit)
                    {
                        //found = true;
                        Base.test.Log(LogStatus.Pass, "Found the room : " + roomName + " to edit");
                        return i;
                        break;
                    }
                    else
                    {
                        i++;
                        Console.WriteLine(roomName+ "   "+ RoomEdit);
                    }
                }
            }
            catch (Exception e)
            {
                Base.test.Log(LogStatus.Fail, "Could not Find the Room to Edit", e);
                return 0;
            }
        }
    }
}