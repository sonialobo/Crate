﻿using Beehive.Global;
using Beehive.Test;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Threading;
using static NUnit.Core.NUnitFramework;

namespace Beehive.Pages.Account
{
    internal class AccountManagement
    {
        //public static ExtentTest test;

        public AccountManagement()
        {
            PageFactory.InitElements(Driver.driver,this);
        }
        #region NavigationElements
        // Finding the Account Tab on the Top Navigation Link
        [FindsBy(How = How.XPath, Using = ".//*[@id='top-bar-menu']/div[1]/ul/li[11]/a")]
        private IWebElement accountTab { get; set; }
        #endregion
        internal void NavigateToAccountManagement()
        {
            Thread.Sleep(1000);
            // Clicking on the account tab
            accountTab.Click();
            Base.test.Log(LogStatus.Info, "Cicked on Account Tab");
        }
        #region Page Web Elements 
        // Finding the Add New User, btn - Button
        [FindsBy(How = How.XPath, Using = "html/body/div[2]/a[1]")]
        private IWebElement addNewUserBtn { get; set; }

        // Finding the Company Name, DD- Drop down
        [FindsBy(How = How.XPath, Using = ".//*[@id='CompanyName']")]
        private IWebElement companyNameDD { get; set; }

        // Finding the Testing, DD- Drop down
        [FindsBy(How = How.XPath, Using = "//option[contains(@value,'14')]")]
        private IWebElement companyNameDDoption { get; set; }

        // Finding the First Name, TB - TextBox
        [FindsBy(How = How.XPath, Using = "//input[@id='FirstName']")]
        private IWebElement firstNameTB { get; set; }

        // Finding the Last Name 
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'LastName')]")]
        private IWebElement lastNameTB { get; set; }

        // Finding the Email Address 
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'EmailAddress')]")]
        private IWebElement eMailTB { get; set; }

        // Finding the PassWord 
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']")]
        private IWebElement passWordTB { get; set; }

        // Finding the Confirm PassWord 
        [FindsBy(How = How.XPath, Using = "//input[@id='ConfirmPassword']")]
        private IWebElement passWordConfirmTB { get; set; }

        // Finding the AddressFinder 
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'autocomplete')]")]
        private IWebElement addressFinderTB { get; set; }

        //Finding the google Address finder, first option
        [FindsBy(How = How.XPath, Using = "html/body/div[4]/div")]
        private IWebElement addressFinderFirstTB { get; set; }

        // Finding the  Create Button 
        [FindsBy(How = How.XPath, Using = "//input[contains(@value,'Create')]")]
        private IWebElement createBtn { get; set; }
        #endregion

        //This method will add / edit the name, email and address
        // Sheet Name and the Row is needed as parameters for reading data from Excel
        private void AddUserData(String SheetName, int RowNumber, bool Edit = false)
        {
            // Populating the Data from Excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, SheetName);
            
            // Sending the first name from Excel
            firstNameTB.Clear();
            firstNameTB.SendKeys(ExcelLib.ReadData(RowNumber, "FirstName"));
            Base.test.Log(LogStatus.Info, "Entered the First Name as " + ExcelLib.ReadData(RowNumber, "FirstName"));

            // Sending the last name from Excel
            lastNameTB.Clear();
            lastNameTB.SendKeys(ExcelLib.ReadData(RowNumber, "LastName"));
            Base.test.Log(LogStatus.Info, "Entered the Last Name as " + ExcelLib.ReadData(RowNumber, "LastName"));

            // Sending the Email  from Excel
            eMailTB.Clear();
            eMailTB.SendKeys(ExcelLib.ReadData(RowNumber, "Email"));
            Base.test.Log(LogStatus.Info, "Entered E-mail as " + ExcelLib.ReadData(RowNumber, "Email"));

            // if editing an existing record, you dont need to enter the password again. 
            if (Edit == false)
            {

                // Sending the password from Excel
                passWordTB.Clear();
                passWordTB.SendKeys(ExcelLib.ReadData(RowNumber, "Password"));

                passWordConfirmTB.Clear();
                passWordConfirmTB.SendKeys(ExcelLib.ReadData(RowNumber, "Password"));
            }
            
            //Sending the address from E-mail
            addressFinderTB.Clear();
            addressFinderTB.SendKeys(ExcelLib.ReadData(RowNumber, "Address"));
            Thread.Sleep(1000);
            
            // cliking the first result on Google Address Finder
            addressFinderFirstTB.Click();
            // will click on the edit button if the email is unique. 
            if (Edit == false)
            {
                createBtn.Click();
                Base.test.Log(LogStatus.Info, "Clicked on Create Button");
            }
            else
            {
                Driver.driver.FindElement(By.XPath("//input[@class='button primary']")).Click();
                Base.test.Log(LogStatus.Info, "Clicked on Update Button Button");
            }
        }



        // Tov verify if the added data is there on the list
        // To do - add a return type and display the list found or not
        
        public bool VerifyData(String screenshotfileName, int RowNumber)
        {
            // a boolean variable to store  true, if email id already exist in the database. 
            bool emailExist = false;
            // to find the E-mail in the UI. 
            bool elementExist = false;
            try
            {
                Thread.Sleep(500);
                // to find if the E-mail exist or not
                elementExist = Driver.driver.FindElement(By.XPath("//p[contains(.,'Email address already used by other user.')]")).Displayed;
                // to save the screenshot if the email exist
                SaveScreenShotClass.SaveScreenshot(Driver.driver, "E-mail_Exist");
                // if the email exist, no need to verify the data that added.
                emailExist = true;
                Base.test.Log(LogStatus.Info,"Email already Exist, Could not add the user!");
            }
            catch
            {
                SaveScreenShotClass.SaveScreenshot(Driver.driver, screenshotfileName);
                //Thread.Sleep(2000);
            }
            // a variable to store if the E-mail ID exist or not.
            bool EmalNotFound = false;
            // if the E-mail is already in the database, no need to verify
            if (elementExist == false)
            {
                // assigning the E-mail that is added to a string varibale. 
                String emailcheck = ExcelLib.ReadData(RowNumber, "Email");
                // for debugging purpose. 
                //Console.WriteLine(emailcheck);
                int i = 1;
                Thread.Sleep(2000);
                // To store the E-mail in a string varible. 
                String emailchecklist = "";
                // if the email is not on the list
                EmalNotFound = true;
                try
                {
                    while (emailExist == false)
                    {
                        emailchecklist = Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + i + "]/td[3]")).Text;
                        if (emailcheck == emailchecklist)
                        {
                            Base.test.Log(LogStatus.Pass, "Verified the data");
                            Base.test.Log(LogStatus.Pass, "Email Verified, Test successfull");
                            emailExist = true;
                            EmalNotFound = false;
                            break;
                            return true;
                        }
                        else
                        {
                            i = i + 1;
                        }
                    }
                }
                catch (Exception e)
                {
                    Base.test.Log(LogStatus.Unknown, "Not found!!", e);
                }
            }
            if (EmalNotFound == true)
            {
                Console.WriteLine("Could not find Email in the list ");
                Base.test.Log(LogStatus.Fail, "Email not in the list");
            }
            return false; 
        }

        public void AddNewUserCommonSteps()
        {
            Thread.Sleep(500);
            addNewUserBtn.Click();
            Base.test.Log(LogStatus.Info, "Cicked on Add New User"); 
            // Selecting the Company Dropdown Lost
            Thread.Sleep(500);
            companyNameDD.Click();

            // Selecting an option from the List
            companyNameDDoption.Click(); Thread.Sleep(500);
            companyNameDDoption.Click();
        }
        internal void AddNewUser_validData()
        {
            // add user common steps 
            AddNewUserCommonSteps();
            // passing the sheet name as parameter for adding data
            AddUserData("Account",2);
            // verifying the data
            VerifyData("Account",2);
         }

        // For adding an invalid data
        internal void AddNewUser_DuplicateData()
        {
            // add user common steps 
            AddNewUserCommonSteps();
            // passing the sheetname as parameter
            AddUserData("Account", 2);
            VerifyData("NoNeed_",2);
        }
        internal void AddNewUser_WithoutMandatoryData()
        {
            // Clickin on the Add New User Button
            addNewUserBtn.Click();
            Thread.Sleep(1000);
            createBtn.Click();

            bool errorMessage = Driver.driver.FindElement(By.XPath("//span[contains(@for,'EmailAddress')]")).Displayed;
            if(errorMessage == true)
            {
                Base.test.Log(LogStatus.Pass, "test successfull");
                Base.test.Log(LogStatus.Info, "Cannot add a new user without mandatory fields");
            }
            else
                Base.test.Log(LogStatus.Fail, "Test failed, Didnt through an error message");

        }

        [FindsBy(How =How.XPath, Using = "//a[contains(.,'Add Admin User')]")]
        private IWebElement AddAdminUserBtn { get; set; }

        internal void AddAdminUser_ValidData()
        {
            Thread.Sleep(500);
            // Clickin on the Add New User Button

            AddAdminUserBtn.Click();
            Thread.Sleep(1000);

            AddUserData("Account", 6);
            VerifyData("AccountAdminUser",6);
        }
        internal void AddAdminuser_DuplicateData()
        {
            Thread.Sleep(500);
            // Clickin on the Add New User Button
            AddAdminUserBtn.Click();
            Thread.Sleep(1000);
            // entering the user details
            AddUserData("Account", 2);
            // verifying the data added exists
            VerifyData("AccountAdminUser",2);
        }
        internal void AddAdminuser_withoutMandatoryFields()
        {
            AddAdminUserBtn.Click();
            Thread.Sleep(1000);

            createBtn.Click();

            bool errorMessage = Driver.driver.FindElement(By.XPath("//span[contains(@for,'EmailAddress')]")).Displayed;
            if (errorMessage == true)
            {
                Base.test.Log(LogStatus.Pass, "test successfull");
                Base.test.Log(LogStatus.Pass, "Cannot add a new user without mandatory fields");
            }
            else
                Base.test.Log(LogStatus.Fail, "Test failed, Didnt through an error message");
        }

        public int findaMailID(string emailCheck)
        {
            // for storing each Email in the UI.
            String emailchecklist;
            int i = 1;
            // to exit the loop 
            bool exitloop = false;
            // loop will continut to exit it either it find an element or the end of list
            try
            {
                while (exitloop == false)
                {
                    emailchecklist = Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + i + "]/td[3]")).Text;
                    if (emailCheck == emailchecklist)
                    {
                        Base.test.Log(LogStatus.Pass,"Found the E-mail ID in the UI");
                        return i;
                        break;
                    }
                    else
                    {
                        i = i + 1;
                        // This line is just for debugging 
                        //Console.WriteLine(Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + i + "]/td[3]")).Text);
                    }
                }
            }
            catch (NotFoundException e)
            {
                Base.test.Log(LogStatus.Pass, "Could not find E-mail in the UI");
                return 0;
            }
            return 0;
        }
        internal void EditAdminUserwith_ValidData()
        {
            // populate the data from excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Account");
            Thread.Sleep(500);
            // to find the email in the list
            int a = findaMailID(ExcelLib.ReadData(12,"Email"));
            Console.WriteLine(a);
            // clicking on the edit button
            if (a != 0)
            {
                Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + a + "]/td[5]/a[1]")).Click();
                Base.test.Log(LogStatus.Pass, "Editing the Email " + ExcelLib.ReadData(12, "Email"));
                AddUserData("Account", 14, true);
                VerifyData("EditedUser", 14);
            }
            else
                Base.test.Log(LogStatus.Pass, "Email already exist, try with a new email!");
        }

        internal void EditAdminUser_withoutMandatoryFields()
        {
            // populate the data from excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Account");
            Thread.Sleep(500);
            // to find the email in the list
            int a = findaMailID(ExcelLib.ReadData(14, "Email"));
            Console.WriteLine(a);

            if (a != 0)
            {
                // clicking on the edit button
                Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + a + "]/td[5]/a[1]")).Click();
                // clearing the contents of email field
                Driver.driver.FindElement(By.XPath("//input[contains(@id,'EmailAddress')]")).Clear();

                // clikcing on the update button
                Driver.driver.FindElement(By.XPath("//input[@class='button primary']")).Click();
                bool errorMessage = Driver.driver.FindElement(By.XPath("//span[@for='EmailAddress']")).Displayed;
                if (errorMessage == true)
                {
                    Base.test.Log(LogStatus.Pass, "test successfull");
                    Base.test.Log(LogStatus.Pass, "Cannot edit a new user without mandatory fields");
                }
            }
            else
                Base.test.Log(LogStatus.Info, "The Email that you are searching to edit is not in the UI list, try with a new emal in Excel sheet!");
        }

        internal void RemoveAnUser()
        {
            // populate the data from excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Account");
            Thread.Sleep(500);
            // to find the email in the list
            int a = findaMailID(ExcelLib.ReadData(26, "Email"));
            Console.WriteLine(a);
            // clicking on the edit button
            if (a != 0)
            {
                Driver.driver.FindElement(By.XPath(".//*[@id='User-List']/tr[" + a + "]/td[5]/a[3]")).Click();
                Thread.Sleep(500);

                Driver.driver.SwitchTo().Alert().Accept();

                int emailNotFound = findaMailID(ExcelLib.ReadData(26, "Email"));
                if (emailNotFound == 0)
                    Base.test.Log(LogStatus.Pass, "Test Successfull, User Removed");
            }
            else
                Base.test.Log(LogStatus.Info, "I cannot remove an E-mail if it didnt exist in the DB!");
        }

    }
}