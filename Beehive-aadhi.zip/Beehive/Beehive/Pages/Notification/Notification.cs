﻿using Beehive.Global;
using Beehive.Test;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Threading;

namespace Beehive.Pages.Notification
{
    internal class Notification
    {
        public Notification()
        {

            PageFactory.InitElements(Driver.driver, this);

        }

        //Navigating to the Notification page
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Notification')]")]
        private IWebElement Notificationtab { set; get; }

        internal void NavigateToNotificationPage()
        {

            Thread.Sleep(1000);
            Notificationtab.Click();
            Base.test.Log(LogStatus.Info, "Clicked on Notification Tab");

        }

        //Selecting community board radio button

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'CommunityBoxRadio')]")]
        private IWebElement select_CommunityBoard { set; get; }

        //Typing message in the message content box
        [FindsBy(How = How.XPath, Using = "//textarea[@id='mesage-content']")]
        private IWebElement messageContent { set; get; }
    
        //Clicking the send notification button
        [FindsBy(How = How.XPath, Using = "//button[@class='button primary']")]
        private IWebElement click_notification_btn { set; get; }

        internal void CommunityBoardMessage()
        {

            // populating data from excel
            ExcelLib.PopulateInCollection(Base.ExcelPath, "Notification");
            select_CommunityBoard.Click();
            
            messageContent.SendKeys(ExcelLib.ReadData(2, "Message"));
            string message = ExcelLib.ReadData(2, "Message");
            Base.test.Log(LogStatus.Info, "The message sent was -> " + message);
            click_notification_btn.Click();
            DashBoardVerify(message);


        }

        private void DashBoardVerify(string message)
        {
            Thread.Sleep(1000);
            Console.WriteLine("message verify");
            string msg = Driver.driver.FindElement(By.XPath("//div[@id='message_marquee']")).Text;
            //string msg= Driver.driver.FindElement(By.XPath("//div[contains(.,' this is just a test message from automation ')]")).Text;
            //string msg = Driver.driver.FindElement(By.XPath("//div[contains(.,' "+ message +" ')]")).Text;
            if (msg == message)
            {
                Base.test.Log(LogStatus.Pass, "Message Displayed on Dash Board");
                Console.WriteLine(msg);
            }
            else
            {
                Base.test.Log(LogStatus.Fail, "Test Failed - Message not  Displayed on Dash Board");
                Console.WriteLine(msg + "    " + message);
            }
                //Thread.Sleep(500);
            //// for storing the Xpath of message tab
            //int i = 1;
            //// for storing the message
            //string msg;
            //try
            //{
            //    while (true)
            //    {
            //        Assert.That(Driver.driver.FindElement(By.XPath("html/body/div[2]/div[2]/div[1]/div/div[2]/div/ul/li[" + i + "]")).Displayed);
            //        msg = Driver.driver.FindElement(By.XPath(".//*[@id='message_marquee']")).Text;
            //        Console.WriteLine(msg);
            //        if (msg == message)
            //        {
            //            Base.test.Log(LogStatus.Pass, "Message Displayed on Dash Board");
            //            Console.WriteLine(msg);
            //        }
            //        else
            //            i++;
            //    }
            //}
            //catch (Exception e)
            //{
            //    Base.test.Log(LogStatus.Info, "Could not find the message  ", e);
            //}
        }

        //Selecting Individual User radio button

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'UserRadio')]")]
        private IWebElement Individual_radiobutn { set; get; }

        internal void Individual_user()
        {
            Individual_radiobutn.Click();

        }

        //Selecting multiple users and multiple companies

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'UserRadio')]")]
        private IWebElement select_individualuser { set; get; }

        //Typing message in the message content box
        [FindsBy(How = How.XPath, Using = "//input[contains(@aria-expanded,'true')]")]
        private IWebElement select_users { set; get; }

        //Clicking the send notification button
        [FindsBy(How = How.XPath, Using = "//p[contains(.,'All Users')]")]
        private IWebElement All_Users { set; get; }

        //Selecting single user
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/form[2]/div[1]/div/div/div/ul/li/span[1]")]
        private IWebElement Single_User { set; get; }

        //Selecting multiple users and multiple companies

        [FindsBy(How = How.XPath, Using = "//input[contains(@aria-expanded,'true')]")]
        private IWebElement Select_Companies { set; get; }

        //Typing message in the message content box
        [FindsBy(How = How.XPath, Using = "//li[contains(.,'All Companies')]")]
        private IWebElement All_Companies { set; get; }

        //Clicking the send notification button
        [FindsBy(How = How.XPath, Using = "//input[contains(@value,'10')]")]
        private IWebElement Select_Dashboard { set; get; }

        //Typing message in the message content box
        [FindsBy(How = How.XPath, Using = "//textarea[contains(@id,'mesage-content')]")]
        private IWebElement Message_Content_Box { set; get; }

        //Clicking the send notification button
        [FindsBy(How = How.XPath, Using = "//button[@id='send-notification']")]
        private IWebElement Send_Notification_Btn { set; get; }

        internal void No_User_Company()
        {
            select_users.Click();
            Select_Companies.Click();
            Send_Notification_Btn.Click();
        }

        internal void Individual_User_One()
        {
            Single_User.Click();

        }

        internal void Individual_User_All()
        {
            select_individualuser.Click();
            select_users.Click();
            All_Users.Click();
            Select_Companies.Click();
            All_Companies.Click();
            Select_Dashboard.Click();
            Message_Content_Box.SendKeys("Hi");
            Send_Notification_Btn.Click();
        }
    }
}