﻿using Beehive.Global;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Beehive.Pages.Company
{
    class AddNewCompany
    {
        // Initializing the web elements 
        public AddNewCompany()
        {
            PageFactory.InitElements(Driver.driver, this);  
        }

        //Finding the Company Tab
        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'/Account/Company')]")]
        private IWebElement companyTab { get; set; }

        //Finding the Add New Company Button
        [FindsBy(How = How.XPath, Using = "html/body/div[2]/a")]
        private IWebElement addNewCompanyButton { get; set; }


        //Finding the Company Name
        [FindsBy(How = How.XPath, Using = "//input[@name='CompanyName']")]
        private IWebElement companyName { get; set; }

        //Finding the Email Address
        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'CompanyEmailAddress')]")]
        private IWebElement eMail { get; set; }

        //Finding the google Address finder
        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'autocomplete')]")]
        private IWebElement addressFinder { get; set; }

        //Finding the google Address finder, first option
        [FindsBy(How = How.XPath, Using = "html/body/div[4]/div")]
        private IWebElement addressFinderFirst { get; set; }

        //Finding the Create Company Button
        [FindsBy(How = How.XPath, Using = "//input[contains(@type,'button')]")]
        private IWebElement createCompanyButton { get; set; }

        internal void AddCompany()
        {
            // Clicking on the Company tab with a wait time. 
            // Driver.driver.FindElement(By.XPath("//a[@href='/Account/Company']"),2).Click();
            Thread.Sleep(2000);
            companyTab.Click();
            //NavigateToCompanyPage.Click();  
            //Driver.driver.FindElement(By.XPath("//a[@href='/Account/AddNewCompany']")).Click();
            Thread.Sleep(1000);
            addNewCompanyButton.Click();

            ExcelLib.PopulateInCollection(@"C:\SD Card\Dropbox\VisualStudio\Projects\Beehive\ExcelData\InputData.xlsx", "Sheet2");
            //Adding the company name from Excel Sheet
            //Driver.driver.FindElement(By.XPath("//input[@name='CompanyName']")).SendKeys(ExcelLib.ReadData(2,"CompanyName"));
            Thread.Sleep(2000);
            companyName.SendKeys(ExcelLib.ReadData(2, "CompanyName"));

            //Adding the E-mail Address from Excel Sheet
            //Driver.driver.FindElement(By.XPath("//input[@name='CompanyEmailAddress']")).SendKeys(ExcelLib.ReadData(2, "Email"));
            Thread.Sleep(1000);
            eMail.SendKeys(ExcelLib.ReadData(2, "Email"));

            //Adding the Address from Excel Sheet. 
            // Need to select the first address appeared. If we don't then there will be a bug. Not logged that bug. 
            //Driver.driver.FindElement(By.XPath("//input[contains(@onfocus,'geolocate()')]")).SendKeys(ExcelLib.ReadData(2, "Address"));
            addressFinder.SendKeys(ExcelLib.ReadData(2, "Address"));
            // Click on Create Company
            Thread.Sleep(2000);
            addressFinderFirst.Click();
            Thread.Sleep(500);
            //Driver.driver.SwitchTo().Alert().Dismiss();

            Thread.Sleep(500);
            // Click on the Create Company Button. Not working..
            createCompanyButton.Click(); createCompanyButton.Click();

            SaveScreenShotClass.SaveScreenshot(Driver.driver, "test");

        }
    }
}
