﻿using Beehive.Global;
using Beehive.Pages.Account;
using Beehive.Pages.Admin;
using Beehive.Pages.Company;
using Beehive.Pages.Notification;
using NUnit.Framework;
using OpenQA.Selenium.Firefox;
using RelevantCodes.ExtentReports;
using System;
using System.Configuration;

namespace Beehive.Test.Sprint_2
{
    // test cases for the account tab  //9 TC done, 5 TC can't do with out fixing the bug 
    [TestFixture]
    [Category("Sprint_2")] 
    class Sprint_2_Acccount : Base
    {        
       // Add a new user in the Account Managment
        [Test]
        public void Account_AddNewUser_ValidData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Add Admin user using Valid Data");//, "Getting the values from excel");
            // Creating an instance
            AccountManagement obj = new AccountManagement();
            // method for navigating to the account page
            obj.NavigateToAccountManagement();
            // method for adding the valid data
            obj.AddNewUser_validData();       
        }       
        [Test]
        public void Account_AddNewUser_DuplicateData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Add Admin user using Duplicate Data");
            // Creating an instance
            AccountManagement obj = new AccountManagement();
            // method for navigating to the account page
            obj.NavigateToAccountManagement();
            // method for adding the Duplicate data
            obj.AddNewUser_DuplicateData();
        }

        // To Do - cannot complete without fixing the bug
        //  [Test]
        // public void Account_AddNewUser_InvalidData()
        [Test]
        public void Account_AddNewUser_withoutMandatoryFields()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Add New User without Mandatory Fields","The user should not able to add new user");
            AccountManagement obj = new AccountManagement();
            obj.NavigateToAccountManagement();
            obj.AddNewUser_WithoutMandatoryData();
        }
        // cannot complete without fixing the bug
        //[Test]
        //public void Account_AddNewUser_Deleted()

        [Test]
        public void Account_AddAdminUser_ValidData()
        {
            test = extent.StartTest("Add Admin user with valid data", "all the input values are valid");
            AccountManagement obj = new AccountManagement();
            obj.NavigateToAccountManagement();
            obj.AddAdminUser_ValidData();
        }
        [Test]
        public void Account_AddAdminUser_DuplicateData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Add New Admin User with Duplicate Fields", "Should not be able to do this");
            AccountManagement obj = new AccountManagement();
            obj.NavigateToAccountManagement();
            obj.AddAdminuser_DuplicateData();
        }
 
        [Test]
        public void Account_AddAdminUser_withoutMandatoryFields()
        {
            test = extent.StartTest("Add New Admin User without Mandatory Fields", "Should not be able to do this");
            AccountManagement obj = new AccountManagement();
            obj.NavigateToAccountManagement();
            obj.AddAdminuser_withoutMandatoryFields();
        }
        // To do - add admin with invalid data
        // To do - delete an admin and add the same admin 
        // the above two test can't be run with out fixing the bug
        [Test]
        public void Account_EditAdminUserwith_validData()
        {
            test = extent.StartTest("Edit Admin User with Valid Data", "Should able to do this if the Email exist in the list");
            // creating an object for account management  class
            AccountManagement obj = new AccountManagement();
            // using the object calling the method for navigating to the account page 
            obj.NavigateToAccountManagement();
            obj.EditAdminUserwith_ValidData();
        }
        [Test]
        public void Account_EditAdminUser_withoutMandatoryFields()
        {
            test = extent.StartTest("Edit Admin User without Mandatory Fields", "Should not be able to do this");
            // creating an object for account management  class
            AccountManagement obj = new AccountManagement();
            // using the object calling the method for navigating to the account page 
            obj.NavigateToAccountManagement();
            obj.EditAdminUser_withoutMandatoryFields();
        }

        [Test]
        public void Account_RemoveanUser()
        {
            test = extent.StartTest("Finally removing the user we want!", "Should be able to do this if such an user exist!");
            // creating an object for account management  class
            AccountManagement obj = new AccountManagement();
            // using the object calling the method for navigating to the account page 
            obj.NavigateToAccountManagement();
            obj.RemoveAnUser();
        }
    }
    // test cases for the admin tab
    [TestFixture]
    [Category("Sprint_2")]
    class Sprint_2_Admin : Base
    {
        [Test]
        public void Admin_AddRoom_ValidData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Admin Tab Add a Room with Valid Data");//, "Getting the values from excel");
            AdminRoom_AddRoom obj = new AdminRoom_AddRoom();
            obj.AddRoom();
            
        }
        [Test]
        public void Admin_AddRoom_InvalidData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Admin Tab Add a Room with InValid Data");//, "Getting the values from excel");
            AdminRoom_AddRoom obj = new AdminRoom_AddRoom();
            obj.AddRoom_InvalidData();
        }
        [Test]
        public void Admin_AddRoom_BlankData()
        {
            test = extent.StartTest("Admin Tab Add a Room with Blank Data");
            AdminRoom_AddRoom obj = new AdminRoom_AddRoom();
            obj.AddRoom_BlankData();
        }
        [Test]
        public void Admin_AddRoom_DuplicateData()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Admin Tab Add a Room with Duplicate Data");
            AdminRoom_AddRoom obj = new AdminRoom_AddRoom();
            obj.AddRoom_DuplicateData();
        }
        [Test]
        public void Admin__EditRoom()
        {
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Admin>>Edit Room with Valid Data");
            AdminRoom_AddRoom obj = new AdminRoom_AddRoom();
            obj.AddRoom_EditData();
        }
    }
    // test cases for the notification tab
    [TestFixture]
    [Category("Sprint_2")]
    class Sprint_2_Notification : Base
    {
        [Test]
        public void click_notification_btn()
        {//TC_007_002
            // creates a toggle for the given test, adds all log events under it    
            test = extent.StartTest("Notification>> Community Board");
            Notification obj = new Notification();
            obj.NavigateToNotificationPage();
            obj.CommunityBoardMessage();
        }
    }
}
