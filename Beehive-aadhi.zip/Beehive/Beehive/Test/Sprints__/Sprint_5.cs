﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beehive.Test.Sprints
{
    #region Book A Room
    [TestFixture]
    class BookARoom : Base
    {
        [Test]
        public void AdminBookARoom()
        {

        }

    }

    #endregion
    #region Staff
    [TestFixture]
    class Staff : Base
    {
       // [Test]
    }
    #endregion

    [TestFixture]
    class Company : Base
    {
        //[Test]
    }
}
