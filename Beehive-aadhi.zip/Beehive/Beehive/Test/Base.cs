﻿using NUnit.Framework;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Beehive.Global;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

namespace Beehive.Test
{

    //[TestFixture]
    public abstract class Base
    {
        #region report path, excel path, screen shot path
        
        // the report path
        public static String ReportPath = ConfigurationManager.AppSettings["ReportPath"];
        // the excel path
        public static readonly string ExcelPath = ConfigurationManager.AppSettings["ExcelPath"];
        // Screenshot path
        public static readonly string ScreenshotPath = ConfigurationManager.AppSettings["ScreenShotPath"];

        public static int Browser = Int32.Parse(ConfigurationManager.AppSettings["Browser"]);
        #endregion

        #region reports
        public static ExtentTest test;
        public static ExtentReports extent;
        #endregion

        #region setup and tear down
        [SetUp]
        public void Inititalize()
        {
           
            // advisasble to read this documentation before proceeding http://extentreports.relevantcodes.com/net/
            switch (Browser)
            {
                case 1:
                    Driver.driver = new FirefoxDriver();
                    break;
                case 2:
                    Driver.driver = new ChromeDriver();
                    break;

            }
            Login loginobj = new Login();
            loginobj.LoginSuccessfull();
            extent = new ExtentReports(ReportPath, false, DisplayOrder.NewestFirst);
            extent.LoadConfig(@"C:\SD Card\Dropbox\VisualStudio\Projects\Beehive\Beehive\Config\Report.xml");

            //Console.WriteLine(ReportPath);
            // to do .. configure the extent report!! extent.config().documentTitle("Automation Report").reportName("Regression");
        }
        [TearDown]
        public void TearDown()
        {
            // Screenshot
            String img = SaveScreenShotClass.SaveScreenshot(Driver.driver, "Report");//AddScreenCapture(@"E:\Dropbox\VisualStudio\Projects\Beehive\TestReports\ScreenShots\");
            test.Log(LogStatus.Info, "Image example: " + img);
            // end test. (Reports)
            extent.EndTest(test);
            // calling Flush writes everything to the log file (Reports)
            extent.Flush();
            // Close the driver :)            
            Driver.driver.Close();
        }
        #endregion

    }
}


